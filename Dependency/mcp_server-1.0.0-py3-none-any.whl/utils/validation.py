"""
Validation Module

Provides validation functions for data passed through the MCP server.
All validation attempts are logged via the logging module.
User does not have direct access - only server uses this module.
"""

import re
from typing import Any, Optional, Dict, Tuple
from core.logger import MCPLogger


class ValidationError(Exception):
    """Custom exception for validation errors."""
    pass


class Validator:
    """
    Validator class for MCP server data validation.
    
    All validation is performed server-side and logged.
    """
    
    @staticmethod
    def validate_session_id(
        session_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate session ID format.
        
        Rules:
        - Must be string
        - Length between 8 and 128 characters
        - Alphanumeric, dash, and underscore only
        
        Args:
            session_id: Session identifier to validate
            context: Additional context for logging
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_type = "session_id"
        
        if not isinstance(session_id, str):
            error = "Session ID must be a string"
            MCPLogger.log_validation(validation_type, session_id, False, error, context)
            return False, error
        
        if not session_id:
            error = "Session ID cannot be empty"
            MCPLogger.log_validation(validation_type, session_id, False, error, context)
            return False, error
        
        if len(session_id) < 8 or len(session_id) > 128:
            error = f"Session ID length must be between 8 and 128 characters (got {len(session_id)})"
            MCPLogger.log_validation(validation_type, session_id, False, error, context)
            return False, error
        
        if not re.match(r'^[a-zA-Z0-9_-]+$', session_id):
            error = "Session ID contains invalid characters (only alphanumeric, dash, underscore allowed)"
            MCPLogger.log_validation(validation_type, session_id, False, error, context)
            return False, error
        
        MCPLogger.log_validation(validation_type, session_id, True, None, context)
        return True, None
    
    @staticmethod
    def validate_user_id(
        user_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate user ID format.
        
        Rules:
        - Must be string
        - Length between 3 and 64 characters
        - Alphanumeric, dash, underscore, @ and . allowed
        
        Args:
            user_id: User identifier to validate
            context: Additional context for logging
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_type = "user_id"
        
        if not isinstance(user_id, str):
            error = "User ID must be a string"
            MCPLogger.log_validation(validation_type, user_id, False, error, context)
            return False, error
        
        if not user_id:
            error = "User ID cannot be empty"
            MCPLogger.log_validation(validation_type, user_id, False, error, context)
            return False, error
        
        if len(user_id) < 3 or len(user_id) > 64:
            error = f"User ID length must be between 3 and 64 characters (got {len(user_id)})"
            MCPLogger.log_validation(validation_type, user_id, False, error, context)
            return False, error
        
        if not re.match(r'^[a-zA-Z0-9_@.-]+$', user_id):
            error = "User ID contains invalid characters (only alphanumeric, dash, underscore, @ and . allowed)"
            MCPLogger.log_validation(validation_type, user_id, False, error, context)
            return False, error
        
        MCPLogger.log_validation(validation_type, user_id, True, None, context)
        return True, None
    
    @staticmethod
    def validate_query(
        query: str,
        max_length: Optional[int] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate user query.
        
        Rules:
        - Must be string
        - Cannot be empty
        - Length limit (default from config or 10000)
        - No null bytes
        
        Args:
            query: User query to validate
            max_length: Maximum allowed length (optional)
            context: Additional context for logging
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_type = "query"
        
        # Get max length from config if not provided
        if max_length is None:
            from core.config import get_config
            config = get_config()
            max_length = config.get_int('MAX_QUERY_LENGTH', 10000, 'validation')
        
        if not isinstance(query, str):
            error = "Query must be a string"
            MCPLogger.log_validation(validation_type, query, False, error, context)
            return False, error
        
        if not query or not query.strip():
            error = "Query cannot be empty"
            MCPLogger.log_validation(validation_type, query, False, error, context)
            return False, error
        
        if len(query) > max_length:
            error = f"Query exceeds maximum length of {max_length} characters (got {len(query)})"
            MCPLogger.log_validation(validation_type, query, False, error, context)
            return False, error
        
        if '\x00' in query:
            error = "Query contains null bytes"
            MCPLogger.log_validation(validation_type, query, False, error, context)
            return False, error
        
        MCPLogger.log_validation(validation_type, query, True, None, context)
        return True, None
    
    @staticmethod
    def validate_tool_arguments(
        arguments: Dict[str, Any],
        max_size: Optional[int] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate tool arguments.
        
        Rules:
        - Must be dictionary
        - Size limit on serialized form
        - No dangerous keys (starting with __)
        
        Args:
            arguments: Tool arguments to validate
            max_size: Maximum size in bytes (optional)
            context: Additional context for logging
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_type = "tool_arguments"
        
        # Get max size from config if not provided
        if max_size is None:
            from core.config import get_config
            config = get_config()
            max_size = config.get_int('MAX_ARGUMENT_SIZE', 100000, 'validation')
        
        if not isinstance(arguments, dict):
            error = "Arguments must be a dictionary"
            MCPLogger.log_validation(validation_type, arguments, False, error, context)
            return False, error
        
        # Check for dangerous keys
        for key in arguments.keys():
            if key.startswith('__'):
                error = f"Argument key '{key}' is not allowed (starts with '__')"
                MCPLogger.log_validation(validation_type, arguments, False, error, context)
                return False, error
        
        # Check size
        try:
            import json
            serialized = json.dumps(arguments)
            if len(serialized) > max_size:
                error = f"Arguments size exceeds maximum of {max_size} bytes (got {len(serialized)})"
                MCPLogger.log_validation(validation_type, arguments, False, error, context)
                return False, error
        except (TypeError, ValueError) as e:
            error = f"Arguments cannot be serialized: {str(e)}"
            MCPLogger.log_validation(validation_type, arguments, False, error, context)
            return False, error
        
        MCPLogger.log_validation(validation_type, arguments, True, None, context)
        return True, None
    
    @staticmethod
    def validate_tool_name(
        tool_name: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate tool name format.
        
        Rules:
        - Must be string
        - Length between 1 and 64 characters
        - Lowercase alphanumeric and underscore only
        - Must start with letter
        
        Args:
            tool_name: Tool name to validate
            context: Additional context for logging
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_type = "tool_name"
        
        if not isinstance(tool_name, str):
            error = "Tool name must be a string"
            MCPLogger.log_validation(validation_type, tool_name, False, error, context)
            return False, error
        
        if not tool_name:
            error = "Tool name cannot be empty"
            MCPLogger.log_validation(validation_type, tool_name, False, error, context)
            return False, error
        
        if len(tool_name) > 64:
            error = f"Tool name exceeds maximum length of 64 characters (got {len(tool_name)})"
            MCPLogger.log_validation(validation_type, tool_name, False, error, context)
            return False, error
        
        if not re.match(r'^[a-z][a-z0-9_]*$', tool_name):
            error = "Tool name must start with lowercase letter and contain only lowercase letters, numbers, and underscores"
            MCPLogger.log_validation(validation_type, tool_name, False, error, context)
            return False, error
        
        MCPLogger.log_validation(validation_type, tool_name, True, None, context)
        return True, None
    
    @staticmethod
    def sanitize_string(
        input_string: str,
        max_length: Optional[int] = None,
        allow_newlines: bool = True
    ) -> str:
        """
        Sanitize a string input.
        
        Args:
            input_string: String to sanitize
            max_length: Maximum length (truncate if exceeded)
            allow_newlines: Whether to allow newline characters
            
        Returns:
            str: Sanitized string
        """
        if not isinstance(input_string, str):
            input_string = str(input_string)
        
        # Remove null bytes
        sanitized = input_string.replace('\x00', '')
        
        # Remove or replace newlines if not allowed
        if not allow_newlines:
            sanitized = sanitized.replace('\n', ' ').replace('\r', ' ')
        
        # Strip control characters except newlines/tabs
        if allow_newlines:
            sanitized = ''.join(
                char for char in sanitized
                if char >= ' ' or char in '\n\r\t'
            )
        else:
            sanitized = ''.join(
                char for char in sanitized
                if char >= ' ' or char == '\t'
            )
        
        # Truncate if needed
        if max_length and len(sanitized) > max_length:
            sanitized = sanitized[:max_length]
        
        return sanitized.strip()
    
    @staticmethod
    def validate_request_message(
        session_id: str,
        user_id: str,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate a complete request message.
        
        Performs validation on all components of a request.
        
        Args:
            session_id: Session identifier
            user_id: User identifier
            query: User query
            context: Additional context
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        validation_context = context or {}
        
        # Validate session ID
        is_valid, error = Validator.validate_session_id(session_id, validation_context)
        if not is_valid:
            return False, f"Invalid session_id: {error}"
        
        # Validate user ID
        is_valid, error = Validator.validate_user_id(user_id, validation_context)
        if not is_valid:
            return False, f"Invalid user_id: {error}"
        
        # Validate query
        is_valid, error = Validator.validate_query(query, None, validation_context)
        if not is_valid:
            return False, f"Invalid query: {error}"
        
        MCPLogger.log_validation(
            "request_message",
            {"session_id": session_id, "user_id": user_id, "query": query[:50] + "..."},
            True,
            None,
            validation_context
        )
        
        return True, None
    
    @staticmethod
    def validate_strict(
        value: Any,
        validation_type: str,
        rules: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Perform strict validation based on custom rules.
        
        Args:
            value: Value to validate
            validation_type: Type of validation
            rules: Dictionary of validation rules
            context: Additional context
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        # Check if strict validation is enabled
        from core.config import get_config
        config = get_config()
        strict_mode = config.get_bool('STRICT_VALIDATION', True, 'validation')
        
        if not strict_mode:
            MCPLogger.log_validation(validation_type, value, True, "Strict mode disabled", context)
            return True, None
        
        # Type check
        if 'type' in rules:
            expected_type = rules['type']
            if not isinstance(value, expected_type):
                error = f"Expected type {expected_type.__name__}, got {type(value).__name__}"
                MCPLogger.log_validation(validation_type, value, False, error, context)
                return False, error
        
        # Length check for strings/lists
        if 'min_length' in rules or 'max_length' in rules:
            length = len(value) if hasattr(value, '__len__') else None
            if length is not None:
                if 'min_length' in rules and length < rules['min_length']:
                    error = f"Length {length} is less than minimum {rules['min_length']}"
                    MCPLogger.log_validation(validation_type, value, False, error, context)
                    return False, error
                if 'max_length' in rules and length > rules['max_length']:
                    error = f"Length {length} exceeds maximum {rules['max_length']}"
                    MCPLogger.log_validation(validation_type, value, False, error, context)
                    return False, error
        
        # Range check for numbers
        if 'min_value' in rules or 'max_value' in rules:
            if isinstance(value, (int, float)):
                if 'min_value' in rules and value < rules['min_value']:
                    error = f"Value {value} is less than minimum {rules['min_value']}"
                    MCPLogger.log_validation(validation_type, value, False, error, context)
                    return False, error
                if 'max_value' in rules and value > rules['max_value']:
                    error = f"Value {value} exceeds maximum {rules['max_value']}"
                    MCPLogger.log_validation(validation_type, value, False, error, context)
                    return False, error
        
        # Pattern check for strings
        if 'pattern' in rules and isinstance(value, str):
            if not re.match(rules['pattern'], value):
                error = f"Value does not match required pattern: {rules['pattern']}"
                MCPLogger.log_validation(validation_type, value, False, error, context)
                return False, error
        
        MCPLogger.log_validation(validation_type, value, True, None, context)
        return True, None


# Convenience functions for common validations
def validate_session(session_id: str, context: Optional[Dict[str, Any]] = None) -> None:
    """
    Validate session ID and raise exception if invalid.
    
    Args:
        session_id: Session identifier
        context: Additional context
        
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = Validator.validate_session_id(session_id, context)
    if not is_valid:
        raise ValidationError(f"Session validation failed: {error}")


def validate_user(user_id: str, context: Optional[Dict[str, Any]] = None) -> None:
    """
    Validate user ID and raise exception if invalid.
    
    Args:
        user_id: User identifier
        context: Additional context
        
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = Validator.validate_user_id(user_id, context)
    if not is_valid:
        raise ValidationError(f"User validation failed: {error}")


def validate_and_sanitize_query(
    query: str,
    context: Optional[Dict[str, Any]] = None
) -> str:
    """
    Validate and sanitize a user query.
    
    Args:
        query: User query
        context: Additional context
        
    Returns:
        str: Sanitized query
        
    Raises:
        ValidationError: If validation fails
    """
    is_valid, error = Validator.validate_query(query, None, context)
    if not is_valid:
        raise ValidationError(f"Query validation failed: {error}")
    
    return Validator.sanitize_string(query, allow_newlines=True)


# Export main classes and functions
__all__ = [
    'Validator',
    'ValidationError',
    'validate_session',
    'validate_user',
    'validate_and_sanitize_query'
]
