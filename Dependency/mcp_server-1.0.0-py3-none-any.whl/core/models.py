from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class ToolProperty(BaseModel):
    type: str
    description: Optional[str] = None

class ToolParameter(BaseModel):
    type: str
    properties: Dict[str, ToolProperty]
    required: List[str] = []

class ToolDefinition(BaseModel):
    name: str
    description: str
    parameters: ToolParameter

class ToolCall(BaseModel):
    tool_name: str
    arguments: Dict[str, Any]

class ToolResult(BaseModel):
    tool_name: str
    result: Any

class RequestMessage(BaseModel):
    session_id: str
    user_id: str
    query: str
    tools: Optional[List[ToolDefinition]] = None
    metadata: Optional[Dict[str, Any]] = None

class ResponseMessage(BaseModel):
    session_id: str
    response: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_results: Optional[List[ToolResult]] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
