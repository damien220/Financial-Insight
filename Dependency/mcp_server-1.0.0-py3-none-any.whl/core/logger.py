"""
Logger Module

Provides centralized logging functionality for the MCP server.
Logs all server changes, user requests, tool executions with detailed context.

Logging Pattern: date/time/user/tool/request
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
from logging.handlers import RotatingFileHandler


class MCPLogger:
    """
    MCP Server Logger with context-aware logging.
    
    Tracks:
    - Server events and state changes
    - User requests and tool executions
    - Errors and exceptions
    - Performance metrics
    """
    
    _instances: Dict[str, logging.Logger] = {}
    _configured: bool = False
    
    @classmethod
    def configure(
        cls,
        log_level: str = "INFO",
        log_dir: Optional[str] = None,
        log_to_console: bool = True,
        log_to_file: bool = True,
        max_file_size: int = 10 * 1024 * 1024,  # 10MB
        backup_count: int = 5
    ) -> None:
        """
        Configure the logging system globally.
        
        Args:
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir: Directory for log files (default: ./logs)
            log_to_console: Enable console logging
            log_to_file: Enable file logging
            max_file_size: Max size of log file before rotation
            backup_count: Number of backup files to keep
        """
        if cls._configured:
            return
        
        # Set log directory
        if log_dir is None:
            log_dir = Path.cwd() / "logs"
        else:
            log_dir = Path(log_dir)
        
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
        
        # Clear existing handlers
        root_logger.handlers.clear()
        
        # Create formatter with detailed context
        formatter = logging.Formatter(
            fmt='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Console handler
        if log_to_console:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(getattr(logging, log_level.upper(), logging.INFO))
            console_handler.setFormatter(formatter)
            root_logger.addHandler(console_handler)
        
        # File handlers
        if log_to_file:
            # Main log file (all logs)
            main_log_file = log_dir / "mcp_server.log"
            main_handler = RotatingFileHandler(
                main_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count
            )
            main_handler.setLevel(logging.DEBUG)
            main_handler.setFormatter(formatter)
            root_logger.addHandler(main_handler)
            
            # Error log file (errors only)
            error_log_file = log_dir / "mcp_errors.log"
            error_handler = RotatingFileHandler(
                error_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count
            )
            error_handler.setLevel(logging.ERROR)
            error_handler.setFormatter(formatter)
            root_logger.addHandler(error_handler)
            
            # Tool execution log file (tool-specific logs)
            tool_log_file = log_dir / "mcp_tools.log"
            tool_handler = RotatingFileHandler(
                tool_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count
            )
            tool_handler.setLevel(logging.INFO)
            tool_handler.setFormatter(formatter)
            # This handler will be added to tool-specific loggers
            cls._tool_handler = tool_handler
        else:
            cls._tool_handler = None
        
        cls._configured = True
    
    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        """
        Get or create a logger instance.
        
        Args:
            name: Logger name (e.g., 'server', 'dispatcher', 'tool.web_search')
            
        Returns:
            logging.Logger: Configured logger instance
        """
        if not cls._configured:
            cls.configure()
        
        if name not in cls._instances:
            logger = logging.getLogger(name)
            
            # Add tool handler to tool loggers
            if name.startswith('tool.') and cls._tool_handler:
                logger.addHandler(cls._tool_handler)
            
            cls._instances[name] = logger
        
        return cls._instances[name]
    
    @classmethod
    def log_server_event(
        cls,
        event: str,
        level: str = "INFO",
        details: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log a server event.
        
        Args:
            event: Event description
            level: Log level
            details: Additional event details
        """
        logger = cls.get_logger('server')
        log_method = getattr(logger, level.lower(), logger.info)
        
        message = f"SERVER_EVENT: {event}"
        if details:
            message += f" | Details: {details}"
        
        log_method(message)
    
    @classmethod
    def log_user_request(
        cls,
        user_id: str,
        session_id: str,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log a user request.
        
        Args:
            user_id: User identifier
            session_id: Session identifier
            query: User query/request
            context: Additional request context
        """
        logger = cls.get_logger('requests')
        
        message = f"USER_REQUEST | User: {user_id} | Session: {session_id} | Query: {query}"
        if context:
            message += f" | Context: {context}"
        
        logger.info(message)
    
    @classmethod
    def log_tool_execution(
        cls,
        tool_name: str,
        user_id: str,
        arguments: Dict[str, Any],
        success: bool,
        result: Optional[Any] = None,
        error: Optional[str] = None,
        execution_time: Optional[float] = None
    ) -> None:
        """
        Log a tool execution with full context.
        
        Args:
            tool_name: Name of the executed tool
            user_id: User who triggered the tool
            arguments: Tool arguments
            success: Whether execution succeeded
            result: Execution result (if successful)
            error: Error message (if failed)
            execution_time: Execution time in seconds
        """
        logger = cls.get_logger(f'tool.{tool_name}')
        
        status = "SUCCESS" if success else "FAILED"
        message = f"TOOL_EXECUTION | Tool: {tool_name} | User: {user_id} | Status: {status}"
        message += f" | Args: {arguments}"
        
        if execution_time:
            message += f" | Time: {execution_time:.3f}s"
        
        if success and result:
            # Log result summary, not full result to avoid log bloat
            result_summary = str(result)[:200] + "..." if len(str(result)) > 200 else str(result)
            message += f" | Result: {result_summary}"
        
        if error:
            message += f" | Error: {error}"
        
        if success:
            logger.info(message)
        else:
            logger.error(message)
    
    @classmethod
    def log_validation(
        cls,
        validation_type: str,
        data: Any,
        is_valid: bool,
        error_message: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log a validation attempt.
        
        Args:
            validation_type: Type of validation performed
            data: Data being validated (sanitized for logging)
            is_valid: Whether validation passed
            error_message: Error message if validation failed
            context: Additional context (user_id, session_id, etc.)
        """
        logger = cls.get_logger('validation')
        
        status = "VALID" if is_valid else "INVALID"
        message = f"VALIDATION | Type: {validation_type} | Status: {status}"
        
        # Sanitize sensitive data for logging
        data_str = str(data)[:100] + "..." if len(str(data)) > 100 else str(data)
        message += f" | Data: {data_str}"
        
        if context:
            message += f" | Context: {context}"
        
        if not is_valid and error_message:
            message += f" | Error: {error_message}"
        
        if is_valid:
            logger.info(message)
        else:
            logger.warning(message)
    
    @classmethod
    def log_config_access(
        cls,
        key: str,
        value_provided: bool,
        requester: Optional[str] = None
    ) -> None:
        """
        Log configuration access.
        
        Args:
            key: Configuration key accessed
            value_provided: Whether a value was provided
            requester: Module requesting the config
        """
        logger = cls.get_logger('config')
        
        status = "PROVIDED" if value_provided else "MISSING"
        message = f"CONFIG_ACCESS | Key: {key} | Status: {status}"
        
        if requester:
            message += f" | Requester: {requester}"
        
        logger.debug(message)
    
    @classmethod
    def log_error(
        cls,
        error: Exception,
        context: Optional[Dict[str, Any]] = None,
        logger_name: str = "error"
    ) -> None:
        """
        Log an exception with context.
        
        Args:
            error: Exception object
            context: Additional context information
            logger_name: Name of logger to use
        """
        logger = cls.get_logger(logger_name)
        
        message = f"EXCEPTION | Type: {type(error).__name__} | Message: {str(error)}"
        
        if context:
            message += f" | Context: {context}"
        
        logger.exception(message, exc_info=error)


# Convenience functions for quick logging
def setup_logging(
    log_level: str = "INFO",
    log_dir: Optional[str] = None,
    log_to_console: bool = True,
    log_to_file: bool = True
) -> None:
    """
    Setup logging with default configuration.
    
    Args:
        log_level: Logging level
        log_dir: Directory for log files
        log_to_console: Enable console logging
        log_to_file: Enable file logging
    """
    MCPLogger.configure(
        log_level=log_level,
        log_dir=log_dir,
        log_to_console=log_to_console,
        log_to_file=log_to_file
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance.
    
    Args:
        name: Logger name
        
    Returns:
        logging.Logger: Logger instance
    """
    return MCPLogger.get_logger(name)


# Export main functions
__all__ = [
    'MCPLogger',
    'setup_logging',
    'get_logger'
]
