"""
Core modules for MCP Server.

This package contains the core infrastructure:
- config: Configuration management with .env support
- dispatcher: Request routing and tool orchestration
- logger: Comprehensive logging system
- models: Pydantic data models
- server: MVP MCP server implementation
"""

__version__ = "1.0.0"

from core.config import Config
from core.logger import MCPLogger
from core.models import (
    RequestMessage,
    ResponseMessage,
    ToolCall,
    ToolDefinition,
    ToolParameter,
    ToolProperty,
    ToolResult,
)

__all__ = [
    "Config",
    "MCPLogger",
    "RequestMessage",
    "ResponseMessage",
    "ToolCall",
    "ToolDefinition",
    "ToolParameter",
    "ToolProperty",
    "ToolResult",
]
