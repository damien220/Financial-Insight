"""
Dispatcher Module

Handles request routing and tool orchestration for the MCP server.
This module is server-side only and hidden from direct user access.
All request/response flow is logged through this module.
"""

from typing import Optional, List, Dict, Any, Tuple
import time
from core.models import (
    RequestMessage,
    ResponseMessage,
    ToolCall,
    ToolResult,
    ToolDefinition
)
from core.logger import MCPLogger
from core.config import get_config
from utils.validation import Validator, ValidationError
from tools.loader import ToolLoader


class Dispatcher:
    """
    Request dispatcher and tool orchestrator.
    
    This class is responsible for:
    - Receiving and validating requests
    - Determining which tools to execute
    - Orchestrating tool execution
    - Aggregating results
    - Logging all request/response activities
    
    The dispatcher is server-side only and not accessible to users directly.
    """
    
    def __init__(self, tool_loader: Optional[ToolLoader] = None):
        """
        Initialize the dispatcher.
        
        Args:
            tool_loader: Optional ToolLoader instance. If None, creates a new one.
        """
        self.logger = MCPLogger.get_logger('dispatcher')
        self.config = get_config()
        
        # Initialize or use provided tool loader
        if tool_loader is None:
            self.tool_loader = ToolLoader()
            tools_auto_load = self.config.get_bool('TOOLS_AUTO_LOAD', True, 'dispatcher')
            if tools_auto_load:
                tool_count = self.tool_loader.load_tools()
                self.logger.info(f"Dispatcher initialized with {tool_count} tools auto-loaded")
        else:
            self.tool_loader = tool_loader
            self.logger.info(f"Dispatcher initialized with provided ToolLoader")
        
        # Get configuration
        self.max_concurrent_tools = self.config.get_int('MAX_CONCURRENT_TOOLS', 5, 'dispatcher')
        self.strict_validation = self.config.get_bool('STRICT_VALIDATION', True, 'dispatcher')
        
        MCPLogger.log_server_event("Dispatcher initialized", "INFO", {
            "max_concurrent_tools": self.max_concurrent_tools,
            "strict_validation": self.strict_validation,
            "available_tools": self.tool_loader.list_tools()
        })
    
    async def dispatch(self, request: RequestMessage) -> ResponseMessage:
        """
        Main dispatch method - processes incoming requests and returns responses.
        
        This is the primary entry point for the dispatcher. It:
        1. Validates the request
        2. Logs the request
        3. Determines tool execution strategy
        4. Executes tools
        5. Aggregates results
        6. Returns response
        
        Args:
            request: RequestMessage from client
            
        Returns:
            ResponseMessage: Response with results or error
        """
        dispatch_start_time = time.time()
        
        # Log incoming request (primary responsibility of dispatcher)
        MCPLogger.log_user_request(
            user_id=request.user_id,
            session_id=request.session_id,
            query=request.query,
            context=request.metadata or {}
        )
        
        try:
            # Step 1: Validate request
            validation_result = self._validate_request(request)
            if not validation_result[0]:
                return self._create_error_response(
                    request.session_id,
                    f"Request validation failed: {validation_result[1]}"
                )
            
            # Step 2: Analyze request and determine tool calls
            tool_calls = self._analyze_request(request)
            
            if not tool_calls:
                # No tools needed, return simple response
                return ResponseMessage(
                    session_id=request.session_id,
                    response="Request processed but no tools were executed."
                )
            
            # Step 3: Execute tools
            tool_results = await self._execute_tools(
                tool_calls,
                request.user_id,
                request.session_id
            )
            
            # Step 4: Aggregate results
            response = self._aggregate_results(request.session_id, tool_results)
            
            # Log dispatch completion
            dispatch_time = time.time() - dispatch_start_time
            self.logger.info(
                f"Dispatch completed | Session: {request.session_id} | "
                f"Tools: {len(tool_calls)} | Time: {dispatch_time:.3f}s"
            )
            
            return response
            
        except Exception as e:
            # Log error
            MCPLogger.log_error(e, {
                "session_id": request.session_id,
                "user_id": request.user_id,
                "query": request.query[:100]
            })
            
            return self._create_error_response(
                request.session_id,
                f"Dispatch error: {str(e)}"
            )
    
    def _validate_request(self, request: RequestMessage) -> Tuple[bool, Optional[str]]:
        """
        Validate incoming request message.
        
        Args:
            request: RequestMessage to validate
            
        Returns:
            Tuple[bool, Optional[str]]: (is_valid, error_message)
        """
        # Use validation module from Phase 1
        is_valid, error = Validator.validate_request_message(
            session_id=request.session_id,
            user_id=request.user_id,
            query=request.query,
            context={
                "dispatcher": "request_validation",
                "has_tools": request.tools is not None
            }
        )
        
        return is_valid, error
    
    def _analyze_request(self, request: RequestMessage) -> List[ToolCall]:
        """
        Analyze request and determine which tools to execute.
        
        This is a simplified implementation that checks if specific tools
        are requested via the tools field in RequestMessage.
        
        In a production implementation, this would use NLP/LLM to determine
        which tools to call based on the query content.
        
        Args:
            request: RequestMessage to analyze
            
        Returns:
            List[ToolCall]: List of tool calls to execute
        """
        tool_calls = []
        
        # If request explicitly specifies tools, use those
        if request.tools:
            for tool_def in request.tools:
                # Extract tool name and create tool call
                tool_call = ToolCall(
                    tool_name=tool_def.name,
                    arguments={}  # Arguments would come from query parsing
                )
                tool_calls.append(tool_call)
            
            self.logger.info(
                f"Analysis: {len(tool_calls)} tool(s) explicitly requested | "
                f"Session: {request.session_id}"
            )
        else:
            # Simple keyword-based tool detection (for testing/demo purposes)
            query_lower = request.query.lower()
            
            if any(word in query_lower for word in ['search', 'find', 'look up', 'google']):
                tool_calls.append(ToolCall(
                    tool_name="web_search",
                    arguments={"query": request.query, "max_results": 5}
                ))
            
            if any(word in query_lower for word in ['weather', 'temperature', 'forecast']):
                # Extract location from query (simplified)
                location = self._extract_location(request.query)
                tool_calls.append(ToolCall(
                    tool_name="get_weather",
                    arguments={"location": location, "units": "celsius"}
                ))
            
            self.logger.info(
                f"Analysis: {len(tool_calls)} tool(s) detected via keyword matching | "
                f"Session: {request.session_id}"
            )
        
        return tool_calls
    
    def _extract_location(self, query: str) -> str:
        """
        Extract location from query (simplified implementation).
        
        In production, this would use NLP/entity recognition.
        
        Args:
            query: User query
            
        Returns:
            str: Extracted location or default
        """
        # Very simple extraction - looks for common patterns
        query_lower = query.lower()
        
        # Common location patterns
        common_cities = ['new york', 'london', 'paris', 'tokyo', 'sydney', 
                        'berlin', 'moscow', 'beijing', 'dubai', 'mumbai']
        
        for city in common_cities:
            if city in query_lower:
                return city.title()
        
        # Default location
        return "New York"
    
    async def _execute_tools(
        self,
        tool_calls: List[ToolCall],
        user_id: str,
        session_id: str
    ) -> List[ToolResult]:
        """
        Execute tool calls and collect results.
        
        Args:
            tool_calls: List of tools to execute
            user_id: User identifier for logging
            session_id: Session identifier
            
        Returns:
            List[ToolResult]: Results from tool executions
        """
        tool_results = []
        
        # Limit concurrent tool execution
        if len(tool_calls) > self.max_concurrent_tools:
            self.logger.warning(
                f"Tool count ({len(tool_calls)}) exceeds max concurrent limit "
                f"({self.max_concurrent_tools}). Limiting execution."
            )
            tool_calls = tool_calls[:self.max_concurrent_tools]
        
        for tool_call in tool_calls:
            execution_start = time.time()
            
            try:
                # Validate tool name
                is_valid, error = Validator.validate_tool_name(
                    tool_call.tool_name,
                    context={"user_id": user_id, "session_id": session_id}
                )
                
                if not is_valid:
                    tool_results.append(ToolResult(
                        tool_name=tool_call.tool_name,
                        result={"error": f"Invalid tool name: {error}"}
                    ))
                    continue
                
                # Validate tool arguments
                is_valid, error = Validator.validate_tool_arguments(
                    tool_call.arguments,
                    context={"user_id": user_id, "tool": tool_call.tool_name}
                )
                
                if not is_valid:
                    tool_results.append(ToolResult(
                        tool_name=tool_call.tool_name,
                        result={"error": f"Invalid arguments: {error}"}
                    ))
                    continue
                
                # Execute tool via ToolLoader
                success, result = await self.tool_loader.execute_tool(
                    tool_call.tool_name,
                    tool_call.arguments
                )
                
                execution_time = time.time() - execution_start
                
                # Log tool execution (dispatcher's responsibility)
                MCPLogger.log_tool_execution(
                    tool_name=tool_call.tool_name,
                    user_id=user_id,
                    arguments=tool_call.arguments,
                    success=success,
                    result=result if success else None,
                    error=result if not success else None,
                    execution_time=execution_time
                )
                
                # Create tool result
                tool_results.append(ToolResult(
                    tool_name=tool_call.tool_name,
                    result=result if success else {"error": result}
                ))
                
            except Exception as e:
                execution_time = time.time() - execution_start
                error_msg = str(e)
                
                # Log error
                MCPLogger.log_tool_execution(
                    tool_name=tool_call.tool_name,
                    user_id=user_id,
                    arguments=tool_call.arguments,
                    success=False,
                    error=error_msg,
                    execution_time=execution_time
                )
                
                tool_results.append(ToolResult(
                    tool_name=tool_call.tool_name,
                    result={"error": f"Execution exception: {error_msg}"}
                ))
        
        return tool_results
    
    def _aggregate_results(
        self,
        session_id: str,
        tool_results: List[ToolResult]
    ) -> ResponseMessage:
        """
        Aggregate tool results into a response message.
        
        Args:
            session_id: Session identifier
            tool_results: List of tool results
            
        Returns:
            ResponseMessage: Aggregated response
        """
        # Check if any tools failed
        has_errors = any(
            isinstance(result.result, dict) and "error" in result.result
            for result in tool_results
        )
        
        # Build response text
        response_parts = []
        for tool_result in tool_results:
            if isinstance(tool_result.result, dict) and "error" in tool_result.result:
                response_parts.append(
                    f"Tool '{tool_result.tool_name}' failed: {tool_result.result['error']}"
                )
            else:
                response_parts.append(
                    f"Tool '{tool_result.tool_name}' executed successfully"
                )
        
        response_text = "\n".join(response_parts)
        
        # Create response message
        response = ResponseMessage(
            session_id=session_id,
            response=response_text,
            tool_results=tool_results,
            error=None if not has_errors else "Some tools encountered errors"
        )
        
        self.logger.info(
            f"Results aggregated | Session: {session_id} | "
            f"Success: {len(tool_results) - sum(1 for r in tool_results if 'error' in str(r.result))} | "
            f"Failed: {sum(1 for r in tool_results if 'error' in str(r.result))}"
        )
        
        return response
    
    def _create_error_response(
        self,
        session_id: str,
        error_message: str
    ) -> ResponseMessage:
        """
        Create an error response message.
        
        Args:
            session_id: Session identifier
            error_message: Error description
            
        Returns:
            ResponseMessage: Error response
        """
        self.logger.error(f"Creating error response | Session: {session_id} | Error: {error_message}")
        
        return ResponseMessage(
            session_id=session_id,
            response=None,
            tool_calls=None,
            tool_results=None,
            error=error_message
        )
    
    def get_available_tools(self) -> List[str]:
        """
        Get list of available tool names.
        
        Returns:
            List[str]: Available tool names
        """
        return self.tool_loader.list_tools()
    
    def get_tool_definitions(self) -> List[ToolDefinition]:
        """
        Get tool definitions for all available tools.
        
        Returns:
            List[ToolDefinition]: Tool definitions
        """
        return self.tool_loader.get_tool_definitions()
    
    def reload_tools(self) -> int:
        """
        Reload all tools from the tools directory.
        
        Returns:
            int: Number of tools loaded
        """
        self.logger.info("Reloading tools...")
        self.tool_loader.clear_tools()
        count = self.tool_loader.load_tools()
        
        MCPLogger.log_server_event("Tools reloaded", "INFO", {
            "tool_count": count,
            "tools": self.tool_loader.list_tools()
        })
        
        return count
    
    def __repr__(self) -> str:
        """String representation."""
        return (
            f"<Dispatcher: {len(self.tool_loader.list_tools())} tools, "
            f"max_concurrent={self.max_concurrent_tools}>"
        )


# Export main class
__all__ = ['Dispatcher']
