"""
Configuration Module

Manages configuration loading from .env files and provides access to
configuration values throughout the application.
All config access is logged via the logging module.
"""

import os
from pathlib import Path
from typing import Any, Optional, Dict, List
from dotenv import load_dotenv
from core.logger import MCPLogger as logger

class Config:
    """
    Configuration manager for MCP server.
    
    Loads configuration from .env file and environment variables.
    Logs all configuration access for auditing.
    """
    
    _instance: Optional['Config'] = None
    _config_loaded: bool = False
    _config_cache: Dict[str, Any] = {}
    
    def __new__(cls):
        """Singleton pattern to ensure single config instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize configuration manager."""
        if not self._config_loaded:
            self._load_config()
    
    def _load_config(self) -> None:
        """
        Load configuration from .env file and environment variables.
        
        Searches for .env file in:
        1. Current working directory
        2. Project root directory
        3. User-specified path via ENV_FILE environment variable
        """
        # Import logger here to avoid circular imports
        from core.logger import MCPLogger
        self._logger = MCPLogger.get_logger('config')
        
        # Try to find .env file
        env_file = self._find_env_file()
        
        if env_file and env_file.exists():
            load_dotenv(env_file, override=True)
            self._logger.info(f"CONFIG_LOADED | Source: {env_file}")
        else:
            self._logger.warning("CONFIG_LOADED | Source: Environment variables only (no .env file found)")
        
        # Load default configuration
        self._load_defaults()
        
        self._config_loaded = True
        self._logger.info("Configuration initialization complete")
    
    def _find_env_file(self) -> Optional[Path]:
        """
        Find .env file in standard locations.
        
        Returns:
            Optional[Path]: Path to .env file or None
        """
        # Check if ENV_FILE is specified
        if 'ENV_FILE' in os.environ:
            custom_path = Path(os.environ['ENV_FILE'])
            if custom_path.exists():
                return custom_path
        
        # Check current directory
        cwd_env = Path.cwd() / '.env'
        if cwd_env.exists():
            return cwd_env
        
        # Check project root (where app.py should be)
        project_root = Path(__file__).parent.parent
        root_env = project_root / '.env'
        if root_env.exists():
            return root_env
        
        return None
    
    def _load_defaults(self) -> None:
        """Load default configuration values."""
        self._defaults = {
            # Server configuration
            'SERVER_HOST': 'localhost',
            'SERVER_PORT': '8080',
            'SERVER_MODE': 'stdio',  # stdio or http
            
            # Logging configuration
            'LOG_LEVEL': 'INFO',
            'LOG_DIR': 'logs',
            'LOG_TO_CONSOLE': 'true',
            'LOG_TO_FILE': 'true',
            
            # Tools configuration
            'TOOLS_DIRECTORY': 'tools',
            'TOOLS_AUTO_LOAD': 'true',
            
            # Security configuration
            'ENABLE_AUTH': 'false',
            'SESSION_TIMEOUT': '3600',  # seconds
            
            # Performance configuration
            'ENABLE_CACHING': 'false',
            'CACHE_TTL': '300',  # seconds
            'MAX_CONCURRENT_TOOLS': '5',
            
            # Validation configuration
            'STRICT_VALIDATION': 'true',
            'MAX_QUERY_LENGTH': '10000',
            'MAX_ARGUMENT_SIZE': '100000',
        }
    
    def get(
        self,
        key: str,
        default: Optional[Any] = None,
        requester: Optional[str] = None,
        cast_type: Optional[type] = None
    ) -> Any:
        """
        Get configuration value by key.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            requester: Name of module requesting the config (for logging)
            cast_type: Type to cast the value to (int, bool, float, etc.)
            
        Returns:
            Any: Configuration value
        """
        # Check cache first
        if key in self._config_cache:
            value = self._config_cache[key]
            logger.log_config_access(key, True, requester)
            return self._cast_value(value, cast_type)
        
        # Check environment variables
        value = os.environ.get(key)
        
        # Check defaults if not in environment
        if value is None:
            value = self._defaults.get(key)
        
        # Use provided default if still None
        if value is None:
            value = default
        
        # Log access
        value_provided = value is not None
        logger.log_config_access(key, value_provided, requester)
        
        # Cache the value
        if value is not None:
            self._config_cache[key] = value
        
        # Cast to requested type
        if value is not None and cast_type is not None:
            value = self._cast_value(value, cast_type)
        
        return value
    
    def _cast_value(self, value: Any, cast_type: Optional[type]) -> Any:
        """
        Cast value to requested type.
        
        Args:
            value: Value to cast
            cast_type: Target type
            
        Returns:
            Any: Casted value
        """
        if cast_type is None or value is None:
            return value
        
        try:
            # Handle boolean specially
            if cast_type == bool:
                if isinstance(value, bool):
                    return value
                return str(value).lower() in ('true', '1', 'yes', 'on')
            
            # Handle list/tuple
            if cast_type in (list, tuple):
                if isinstance(value, str):
                    return cast_type(v.strip() for v in value.split(','))
                return cast_type(value)
            
            # Standard casting
            return cast_type(value)
        except (ValueError, TypeError) as e:
            self._logger.warning(f"Failed to cast config value '{value}' to {cast_type}: {e}")
            return value
    
    def get_int(self, key: str, default: Optional[int] = None, requester: Optional[str] = None) -> Optional[int]:
        """Get integer configuration value."""
        return self.get(key, default, requester, int)
    
    def get_bool(self, key: str, default: Optional[bool] = None, requester: Optional[str] = None) -> Optional[bool]:
        """Get boolean configuration value."""
        return self.get(key, default, requester, bool)
    
    def get_float(self, key: str, default: Optional[float] = None, requester: Optional[str] = None) -> Optional[float]:
        """Get float configuration value."""
        return self.get(key, default, requester, float)
    
    def get_list(self, key: str, default: Optional[List] = None, requester: Optional[str] = None) -> Optional[List]:
        """Get list configuration value (comma-separated string)."""
        return self.get(key, default, requester, list)
    
    def set(self, key: str, value: Any, requester: Optional[str] = None) -> None:
        """
        Set configuration value (runtime only, not persisted).
        
        Args:
            key: Configuration key
            value: Configuration value
            requester: Module setting the config
        """
        self._config_cache[key] = value
        self._logger.info(f"CONFIG_SET | Key: {key} | Value: {value} | Requester: {requester}")
    
    def has(self, key: str) -> bool:
        """
        Check if configuration key exists.
        
        Args:
            key: Configuration key
            
        Returns:
            bool: True if key exists
        """
        return (
            key in self._config_cache or
            key in os.environ or
            key in self._defaults
        )
    
    def get_all(self, prefix: Optional[str] = None) -> Dict[str, Any]:
        """
        Get all configuration values, optionally filtered by prefix.
        
        Args:
            prefix: Optional prefix to filter keys (e.g., 'SERVER_')
            
        Returns:
            Dict[str, Any]: Configuration dictionary
        """
        config = {}
        
        # Merge defaults, environment, and cache
        all_keys = set(self._defaults.keys()) | set(os.environ.keys()) | set(self._config_cache.keys())
        
        for key in all_keys:
            if prefix is None or key.startswith(prefix):
                config[key] = self.get(key, requester='get_all')
        
        return config
    
    def reload(self) -> None:
        """
        Reload configuration from .env file.
        
        Clears cache and reloads from file and environment.
        """
        self._logger.info("Reloading configuration...")
        self._config_cache.clear()
        self._config_loaded = False
        self._load_config()
    
    def validate_required(self, required_keys: List[str]) -> tuple[bool, List[str]]:
        """
        Validate that required configuration keys are present.
        
        Args:
            required_keys: List of required configuration keys
            
        Returns:
            tuple[bool, List[str]]: (all_present, missing_keys)
        """
        missing = [key for key in required_keys if not self.has(key)]
        
        if missing:
            self._logger.error(f"Missing required configuration keys: {missing}")
            return False, missing
        
        return True, []
    
    def __repr__(self) -> str:
        """String representation."""
        return f"<Config: {len(self._config_cache)} cached values>"


# Singleton instance
_config_instance: Optional[Config] = None


def get_config() -> Config:
    """
    Get the global configuration instance.
    
    Returns:
        Config: Configuration manager instance
    """
    global _config_instance
    if _config_instance is None:
        _config_instance = Config()
    return _config_instance


def get_config_value(
    key: str,
    default: Optional[Any] = None,
    requester: Optional[str] = None
) -> Any:
    """
    Convenience function to get a configuration value.
    
    Args:
        key: Configuration key
        default: Default value
        requester: Module requesting the config
        
    Returns:
        Any: Configuration value
    """
    return get_config().get(key, default, requester)


# Export main functions and classes
__all__ = [
    'Config',
    'get_config',
    'get_config_value'
]
