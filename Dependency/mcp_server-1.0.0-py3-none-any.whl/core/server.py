"""
MCP Server - Phase 2 Core Server Implementation

This module implements the MVP (Minimum Viable Product) MCP server that:
- Receives user requests via stdin/stdout (JSON-based protocol)
- Routes requests to the dispatcher for processing
- Returns responses to users
- Handles basic session management (minimal implementation)
- Handles basic errors (minimal implementation)

FUTURE ENHANCEMENTS (noted in PACKAGE_ARCHITECTURE.txt):
- Separate error handling module with sophisticated error recovery
- Separate session management module with database persistence
- HTTP/WebSocket support in addition to stdio
- Request queuing and rate limiting
- Advanced monitoring and health checks

The server does NOT log messages - all logging is delegated to the dispatcher.
"""

import sys
import json
import asyncio
from typing import Dict, Any, Optional, Set
from datetime import datetime, timedelta

from core.models import RequestMessage, ResponseMessage
from core.dispatcher import Dispatcher
from core.config import Config


class MCPServer:
    """
    MVP MCP Server - Handles stdio communication and basic session management.
    
    This is a minimal implementation focusing on core functionality:
    - JSON-based stdio protocol
    - Request/response handling
    - Basic session tracking (in-memory)
    - Minimal error handling
    
    The server delegates all validation and logging to the dispatcher.
    """
    
    def __init__(self, dispatcher: Optional[Dispatcher] = None):
        """
        Initialize the MCP Server.
        
        Args:
            dispatcher: Optional dispatcher instance. If None, creates a new one.
        """
        self.dispatcher = dispatcher or Dispatcher()
        self.config = Config()
        
        # Minimal session management (in-memory)
        # TODO: Replace with dedicated session management module + database
        self.active_sessions: Set[str] = set()
        self.session_metadata: Dict[str, Dict[str, Any]] = {}
        
        # Server state
        self.running = False
        self.request_count = 0
        
        # Configuration
        self.session_timeout = self.config.get_int('SESSION_TIMEOUT_MINUTES', 30)
        self.max_sessions = self.config.get_int('MAX_ACTIVE_SESSIONS', 1000)
    
    def _create_error_response(
        self,
        session_id: str,
        error_message: str,
        error_code: Optional[str] = None
    ) -> ResponseMessage:
        """
        Create an error response message.
        
        Minimal error handling - creates a simple error response.
        TODO: Replace with dedicated error handling module for:
        - Error categorization and recovery strategies
        - Error logging and monitoring
        - User-friendly error messages
        - Retry logic and circuit breakers
        
        Args:
            session_id: Session identifier
            error_message: Error description
            error_code: Optional error code
            
        Returns:
            ResponseMessage with error details
        """
        return ResponseMessage(
            session_id=session_id,
            response=f"Error: {error_message}",
            tool_results=[],
            error=error_message,
            metadata={
                "error_code": error_code or "UNKNOWN_ERROR",
                "timestamp": datetime.now().isoformat(),
                "server": "mcp_server_v1"
            }
        )
    
    def _register_session(self, session_id: str, user_id: str) -> bool:
        """
        Register a new session or update existing one.
        
        Minimal session management - in-memory tracking only.
        TODO: Replace with dedicated session management module for:
        - Database persistence (PostgreSQL/Redis)
        - Distributed session management
        - Session recovery and migration
        - Advanced session analytics
        - User authentication and authorization
        
        Args:
            session_id: Session identifier
            user_id: User identifier
            
        Returns:
            True if session registered/updated, False if max sessions reached
        """
        # Check if we've reached max sessions
        if session_id not in self.active_sessions and len(self.active_sessions) >= self.max_sessions:
            return False
        
        # Register or update session
        self.active_sessions.add(session_id)
        self.session_metadata[session_id] = {
            "user_id": user_id,
            "created_at": self.session_metadata.get(session_id, {}).get("created_at", datetime.now()),
            "last_activity": datetime.now(),
            "request_count": self.session_metadata.get(session_id, {}).get("request_count", 0) + 1
        }
        
        return True
    
    def _cleanup_expired_sessions(self) -> int:
        """
        Remove expired sessions from memory.
        
        Minimal implementation - simple timeout-based cleanup.
        TODO: Dedicated session management module will handle:
        - Graceful session termination
        - Session state persistence before cleanup
        - Configurable cleanup strategies
        - Session expiration notifications
        
        Returns:
            Number of sessions cleaned up
        """
        cutoff_time = datetime.now() - timedelta(minutes=self.session_timeout)
        expired_sessions = []
        
        for session_id, metadata in self.session_metadata.items():
            if metadata["last_activity"] < cutoff_time:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            self.active_sessions.discard(session_id)
            del self.session_metadata[session_id]
        
        return len(expired_sessions)
    
    def _get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get session metadata.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Session metadata dict or None if not found
        """
        return self.session_metadata.get(session_id)
    
    async def process_request(self, request_data: Dict[str, Any]) -> ResponseMessage:
        """
        Process a single request through the dispatcher.
        
        This is the main request processing pipeline:
        1. Parse request data into RequestMessage
        2. Register/update session (minimal implementation)
        3. Delegate to dispatcher for validation, routing, and execution
        4. Return response
        
        Error handling is minimal - catches exceptions and returns error responses.
        The dispatcher handles all validation and logging.
        
        Args:
            request_data: Raw request data dictionary
            
        Returns:
            ResponseMessage with results or error
        """
        # Get session_id safely (ensure it's a string)
        session_id = str(request_data.get("session_id", "unknown"))
        
        try:
            # Parse request message
            request = RequestMessage(**request_data)
            
            # Minimal session management
            if not self._register_session(request.session_id, request.user_id):
                return self._create_error_response(
                    request.session_id,
                    f"Maximum number of active sessions reached ({self.max_sessions})",
                    "MAX_SESSIONS_EXCEEDED"
                )
            
            # Increment request counter
            self.request_count += 1
            
            # Delegate to dispatcher (dispatcher handles validation and logging)
            response = await self.dispatcher.dispatch(request)
            
            return response
            
        except ValueError as e:
            # Request parsing error (Pydantic validation)
            return self._create_error_response(
                session_id,
                f"Invalid request format: {str(e)}",
                "INVALID_REQUEST_FORMAT"
            )
        except Exception as e:
            # Unexpected error - minimal handling
            # TODO: Dedicated error handling module will provide:
            # - Detailed error logging and tracking
            # - Error recovery strategies
            # - User notification system
            return self._create_error_response(
                session_id,
                f"Server error: {str(e)}",
                "INTERNAL_SERVER_ERROR"
            )
    
    async def handle_stdio_request(self, line: str) -> Optional[str]:
        """
        Handle a single line of JSON input from stdin.
        
        Args:
            line: JSON string from stdin
            
        Returns:
            JSON response string or None for control messages
        """
        try:
            request_data = json.loads(line.strip())
            
            # Handle control messages
            if request_data.get("type") == "ping":
                return json.dumps({"type": "pong", "timestamp": datetime.now().isoformat()})
            
            if request_data.get("type") == "shutdown":
                self.running = False
                return json.dumps({"type": "shutdown_ack", "message": "Server shutting down"})
            
            if request_data.get("type") == "status":
                return json.dumps({
                    "type": "status",
                    "running": self.running,
                    "active_sessions": len(self.active_sessions),
                    "total_requests": self.request_count,
                    "available_tools": self.dispatcher.get_available_tools()
                })
            
            # Process normal request
            response = await self.process_request(request_data)
            return response.model_dump_json()
            
        except json.JSONDecodeError as e:
            error_response = self._create_error_response(
                "unknown",
                f"Invalid JSON: {str(e)}",
                "JSON_PARSE_ERROR"
            )
            return error_response.model_dump_json()
        except Exception as e:
            error_response = self._create_error_response(
                "unknown",
                f"Request handling error: {str(e)}",
                "REQUEST_HANDLER_ERROR"
            )
            return error_response.model_dump_json()
    
    async def run_stdio(self):
        """
        Run the server in stdio mode (main operation mode).
        
        Reads JSON requests from stdin, processes them, and writes JSON responses to stdout.
        This is the primary interface for MCP protocol communication.
        
        Control messages:
        - {"type": "ping"} - Returns pong for health checks
        - {"type": "status"} - Returns server status
        - {"type": "shutdown"} - Gracefully shuts down server
        """
        self.running = True
        
        # Write startup message
        startup_msg = {
            "type": "server_ready",
            "message": "MCP Server started",
            "available_tools": self.dispatcher.get_available_tools(),
            "max_sessions": self.max_sessions
        }
        print(json.dumps(startup_msg), flush=True)
        
        try:
            # Read from stdin line by line
            loop = asyncio.get_event_loop()
            
            while self.running:
                # Periodic session cleanup
                if self.request_count % 100 == 0:
                    self._cleanup_expired_sessions()
                
                # Read line from stdin (non-blocking)
                try:
                    line = await loop.run_in_executor(None, sys.stdin.readline)
                    
                    if not line:  # EOF
                        break
                    
                    # Process request
                    response = await self.handle_stdio_request(line)
                    
                    if response:
                        print(response, flush=True)
                        
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    # Minimal error handling - send error response
                    error_response = self._create_error_response(
                        "unknown",
                        f"Error processing request: {str(e)}",
                        "PROCESSING_ERROR"
                    )
                    print(error_response.model_dump_json(), flush=True)
        
        finally:
            # Cleanup on shutdown
            self.running = False
            shutdown_msg = {
                "type": "server_shutdown",
                "message": "MCP Server stopped",
                "total_requests_processed": self.request_count
            }
            print(json.dumps(shutdown_msg), flush=True)
    
    async def run_single_request(self, request_data: Dict[str, Any]) -> ResponseMessage:
        """
        Process a single request and return the response.
        
        Useful for testing and programmatic server usage.
        
        Args:
            request_data: Request data dictionary
            
        Returns:
            ResponseMessage
        """
        return await self.process_request(request_data)
    
    def get_server_stats(self) -> Dict[str, Any]:
        """
        Get current server statistics.
        
        Returns:
            Dictionary with server stats
        """
        return {
            "running": self.running,
            "total_requests": self.request_count,
            "active_sessions": len(self.active_sessions),
            "max_sessions": self.max_sessions,
            "session_timeout_minutes": self.session_timeout,
            "available_tools": self.dispatcher.get_available_tools()
        }
    
    def reload_tools(self):
        """Reload tools via dispatcher."""
        self.dispatcher.reload_tools()


async def main():
    """
    Main entry point for running the server standalone.
    
    This is primarily for testing. Production usage should go through app.py.
    """
    server = MCPServer()
    await server.run_stdio()


if __name__ == "__main__":
    asyncio.run(main())
