"""
Search Tools Package

This package contains search-related tools.
"""

from tools.search.web_search_tool import WebSearchTool

__all__ = ["WebSearchTool"]
