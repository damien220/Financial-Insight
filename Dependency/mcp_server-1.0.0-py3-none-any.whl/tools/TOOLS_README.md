# Tools Package Documentation

## Overview

The **tools** package provides a reusable, extensible framework for implementing and managing tools in the MCP (Model Context Protocol) server. This package follows object-oriented design principles and provides a clean abstraction layer for tool development.

## Architecture

### Core Components

1. **BaseTool** (`base.py`) - Abstract base class defining the tool interface
2. **ToolLoader** (`loader.py`) - Dynamic tool discovery and management system
3. **Concrete Tools** - Example implementations (web search, weather)

## Package Structure

```
tools/
├── __init__.py              # Package exports
├── base.py                  # BaseTool abstract class
├── loader.py                # ToolLoader class
├── search/
│   ├── __init__.py
│   └── web_search_tool.py   # Example: Web search tool
└── weather/
    ├── __init__.py
    └── weather_tool.py      # Example: Weather tool
```

## Core Classes

### BaseTool (Abstract Class)

The foundation of all tools. Provides:

- **Abstract Methods** (must be implemented):
  - `execute(**kwargs)` - Tool's main functionality
  - `get_name()` - Returns unique tool name
  - `get_description()` - Returns tool description
  - `get_parameters_schema()` - Returns parameter schema

- **Concrete Methods** (reusable):
  - `get_definition()` - Returns ToolDefinition model
  - `validate_arguments()` - Validates input arguments
  - `_check_type()` - Type validation helper

### ToolLoader

Manages tool lifecycle:

- **Discovery**: Automatically finds tool modules
- **Loading**: Dynamically imports and instantiates tools
- **Registration**: Manages tool registry
- **Execution**: Validates and executes tools

#### Key Methods:

```python
loader = ToolLoader()
loader.load_tools()                          # Load all tools
loader.get_tool("tool_name")                # Get specific tool
loader.list_tools()                          # List all tool names
loader.get_tool_definitions()               # Get all definitions
await loader.execute_tool(name, args)       # Execute a tool
```

## Creating Custom Tools

### Step 1: Create Tool Class

Inherit from `BaseTool` and implement required methods:

```python
from tools.base import BaseTool
from typing import Dict, Any

class MyCustomTool(BaseTool):
    def get_name(self) -> str:
        return "my_custom_tool"
    
    def get_description(self) -> str:
        return "Description of what the tool does"
    
    def get_parameters_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "param1": {
                    "type": "string",
                    "description": "First parameter"
                },
                "param2": {
                    "type": "integer",
                    "description": "Second parameter"
                }
            },
            "required": ["param1"]
        }
    
    async def execute(self, param1: str, param2: int = 0, **kwargs) -> Any:
        # Implement your tool logic here
        result = f"Processed {param1} with {param2}"
        return result
```

### Step 2: Place in Directory Structure

Create a directory for your tool category:

```
tools/
└── mycategory/
    ├── __init__.py
    └── my_custom_tool.py
```

### Step 3: Tool Auto-Discovery

The `ToolLoader` will automatically discover your tool if:
- File name ends with `_tool.py`
- Class inherits from `BaseTool`
- Located in a subdirectory of `tools/`

## Example Tools

### WebSearchTool

Located in `tools/search/web_search_tool.py`

**Purpose**: Simulates web search functionality

**Parameters**:
- `query` (string, required) - Search query
- `max_results` (integer, optional) - Max results (default: 5)

**Usage**:
```python
result = await loader.execute_tool(
    "web_search",
    {"query": "Python MCP", "max_results": 3}
)
```

### WeatherTool

Located in `tools/weather/weather_tool.py`

**Purpose**: Simulates weather information retrieval

**Parameters**:
- `location` (string, required) - Location name
- `units` (string, optional) - Temperature units (default: celsius)

**Usage**:
```python
result = await loader.execute_tool(
    "get_weather",
    {"location": "New York", "units": "fahrenheit"}
)
```

## Parameter Schema Format

Tools use JSON Schema for parameter definition:

```python
{
    "type": "object",
    "properties": {
        "param_name": {
            "type": "string|integer|number|boolean|array|object",
            "description": "Parameter description"
        }
    },
    "required": ["param1", "param2"]
}
```

### Supported Types:
- `string` - Text values
- `integer` - Whole numbers
- `number` - Integers or floats
- `boolean` - True/False
- `array` - Lists
- `object` - Dictionaries

## Validation

The `BaseTool` class provides automatic validation:

1. **Required Parameters**: Checks all required params are present
2. **Type Checking**: Validates parameter types match schema
3. **Unknown Parameters**: Detects unexpected parameters

Example validation flow:
```python
is_valid, error_msg = tool.validate_arguments({"query": "test"})
if not is_valid:
    print(f"Validation error: {error_msg}")
```

## Integration with MCP Server

The tools package integrates with the MCP server core:

```python
from tools.loader import ToolLoader
from core.models import ToolDefinition

# Initialize
loader = ToolLoader()
loader.load_tools()

# Get definitions for MCP protocol
definitions: List[ToolDefinition] = loader.get_tool_definitions()

# Execute tools
success, result = await loader.execute_tool(tool_name, arguments)
```

## Testing

A test script (`test_tools.py`) is provided to verify functionality:

```bash
python3 test_tools.py
```

The test script demonstrates:
- Tool loading and discovery
- Tool execution
- Validation (success and failure cases)
- Error handling

## Extending the Framework

### Adding Tool Categories

1. Create a new directory under `tools/`
2. Add `__init__.py` with exports
3. Create tool files ending with `_tool.py`

### Custom Validation

Override `validate_arguments()` for custom validation:

```python
def validate_arguments(self, arguments: Dict[str, Any]) -> tuple[bool, Optional[str]]:
    # Call parent validation first
    is_valid, error = super().validate_arguments(arguments)
    if not is_valid:
        return is_valid, error
    
    # Add custom validation logic
    if arguments.get("param1") == "invalid":
        return False, "param1 cannot be 'invalid'"
    
    return True, None
```

### Async vs Sync Tools

All tools use async `execute()` method by default. For sync operations, use async wrapper:

```python
async def execute(self, **kwargs) -> Any:
    # Sync operation wrapped in async
    result = self._sync_operation(kwargs)
    return result

def _sync_operation(self, kwargs):
    # Your synchronous code here
    pass
```

## Best Practices

1. **Naming**: Use descriptive, lowercase names with underscores
2. **Documentation**: Include clear descriptions for tools and parameters
3. **Error Handling**: Use try-except in execute() and return meaningful errors
4. **Type Hints**: Use type hints for better IDE support
5. **Testing**: Create minimal mock implementations for testing
6. **Reusability**: Keep tools focused and single-purpose

## Design Principles

- **Separation of Concerns**: Tools are independent, loader manages lifecycle
- **Open/Closed**: Open for extension (new tools), closed for modification (base classes)
- **Dependency Inversion**: Depend on abstractions (BaseTool), not concrete implementations
- **Single Responsibility**: Each tool does one thing well

## Future Enhancements

Potential areas for extension:
- Tool dependencies and chaining
- Configuration management per tool
- Tool versioning
- Permission/authorization system
- Rate limiting
- Caching layer
- Tool analytics and monitoring

---

**Note**: The example tools (web search, weather) use mock data for testing. In production, replace with actual API integrations.
