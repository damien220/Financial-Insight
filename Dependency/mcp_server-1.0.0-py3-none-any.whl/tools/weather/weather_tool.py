"""
Weather Tool

Example tool implementation for getting weather information.
This is a minimal implementation for testing purposes.
"""

from typing import Dict, Any
from tools.base import BaseTool


class WeatherTool(BaseTool):
    """
    A tool for getting weather information.
    
    This is a minimal example implementation that simulates weather data retrieval.
    In a real application, this would integrate with actual weather APIs.
    """
    
    def __init__(self):
        """Initialize the weather tool."""
        super().__init__()
    
    def get_name(self) -> str:
        """Get the tool name."""
        return "get_weather"
    
    def get_description(self) -> str:
        """Get the tool description."""
        return "Get current weather information for a specified location"
    
    def get_parameters_schema(self) -> Dict[str, Any]:
        """
        Get the parameter schema for weather queries.
        
        Returns:
            Dict[str, Any]: Schema defining location and optional units parameters
        """
        return {
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The location (city name or coordinates) to get weather for"
                },
                "units": {
                    "type": "string",
                    "description": "Temperature units: 'celsius', 'fahrenheit', or 'kelvin' (default: celsius)"
                }
            },
            "required": ["location"]
        }
    
    async def execute(self, location: str, units: str = "celsius", **kwargs) -> Dict[str, Any]:
        """
        Get weather information for a location.
        
        This is a minimal implementation that returns mock data for testing.
        In a production environment, this would call actual weather APIs.
        
        Args:
            location: The location to get weather for
            units: Temperature units (celsius, fahrenheit, or kelvin)
            **kwargs: Additional arguments (ignored)
            
        Returns:
            Dict[str, Any]: Weather information including temperature, conditions, etc.
        """
        # Mock temperature based on units
        temp_map = {
            "celsius": 22,
            "fahrenheit": 72,
            "kelvin": 295
        }
        
        temperature = temp_map.get(units.lower(), 22)
        
        # Mock implementation for testing
        return {
            "location": location,
            "temperature": temperature,
            "units": units,
            "conditions": "Partly Cloudy",
            "humidity": 65,
            "wind_speed": 12,
            "wind_direction": "NW",
            "forecast": [
                {"day": "Today", "high": temperature + 3, "low": temperature - 5, "conditions": "Partly Cloudy"},
                {"day": "Tomorrow", "high": temperature + 5, "low": temperature - 3, "conditions": "Sunny"},
                {"day": "Day After", "high": temperature + 2, "low": temperature - 4, "conditions": "Cloudy"}
            ]
        }
