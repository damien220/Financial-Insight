#!/usr/bin/env python3
"""
MCP Server Application Entry Point

This is the main entry point for running the MCP server application.
It provides a CLI interface for starting, stopping, and managing the server.

The application is intentionally lightweight - it delegates all heavy lifting
to the server module, which handles its own config and logging initialization.

Usage:
    # Start the server (stdio mode - default)
    python app.py

    # Start with explicit mode
    python app.py --mode stdio

    # Show version
    python app.py --version

    # Show help
    python app.py --help

Architecture:
    app.py (CLI) → core/server.py (Config, Logging, Dispatcher, Tools)
"""

import sys
import asyncio
import argparse
import signal
from typing import Optional

from core.server import MCPServer
from core.config import Config
from core.logger import MCPLogger


# Application metadata
APP_NAME = "MCP Server"
APP_VERSION = "1.0.0"
APP_DESCRIPTION = "Medium-level Model Context Protocol Server"


class Application:
    """
    Application orchestrator - lightweight CLI wrapper around MCPServer.
    
    Responsibilities:
    - Parse CLI arguments
    - Initialize server
    - Handle startup/shutdown signals
    - Provide user feedback during startup/shutdown
    
    The server itself handles config and logging initialization.
    """
    
    def __init__(self):
        """Initialize the application."""
        self.server: Optional[MCPServer] = None
        self.running = False
        self._shutdown_event = asyncio.Event()
    
    def _setup_signal_handlers(self):
        """
        Setup signal handlers for graceful shutdown.
        
        Handles SIGINT (Ctrl+C) and SIGTERM for clean shutdown.
        """
        def signal_handler(signum, frame):
            """Handle shutdown signals."""
            if not self._shutdown_event.is_set():
                print(f"\n\nReceived shutdown signal ({signum}). Shutting down gracefully...", 
                      file=sys.stderr)
                self._shutdown_event.set()
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    async def startup(self) -> bool:
        """
        Initialize and start the server.
        
        The server handles its own config and logging initialization.
        
        Returns:
            True if startup successful, False otherwise
        """
        try:
            # Print startup banner
            print(f"\n{'=' * 70}", file=sys.stderr)
            print(f"{APP_NAME} v{APP_VERSION}", file=sys.stderr)
            print(f"{APP_DESCRIPTION}", file=sys.stderr)
            print(f"{'=' * 70}\n", file=sys.stderr)
            
            # Initialize server (server handles config and logging)
            print("Initializing server...", file=sys.stderr)
            self.server = MCPServer()
            
            # Display server configuration
            stats = self.server.get_server_stats()
            print(f"Configuration:", file=sys.stderr)
            print(f"  - Max sessions: {stats['max_sessions']}", file=sys.stderr)
            print(f"  - Session timeout: {stats['session_timeout_minutes']} minutes", file=sys.stderr)
            print(f"  - Available tools: {len(stats['available_tools'])}", file=sys.stderr)
            for tool_name in stats['available_tools']:
                print(f"    • {tool_name}", file=sys.stderr)
            
            print(f"\n{'=' * 70}\n", file=sys.stderr)
            print("Server ready. Waiting for requests on stdin...\n", file=sys.stderr)
            
            self.running = True
            return True
            
        except Exception as e:
            print(f"\nFATAL ERROR during startup: {e}", file=sys.stderr)
            return False
    
    async def shutdown(self):
        """
        Gracefully shutdown the server.
        
        Performs cleanup and ensures resources are released.
        """
        if not self.running:
            return
        
        print("\n\nShutting down server...", file=sys.stderr)
        self.running = False
        
        if self.server:
            # Get final stats
            stats = self.server.get_server_stats()
            print(f"Final statistics:", file=sys.stderr)
            print(f"  - Total requests processed: {stats['total_requests']}", file=sys.stderr)
            print(f"  - Active sessions: {stats['active_sessions']}", file=sys.stderr)
        
        print("\nServer stopped.", file=sys.stderr)
        print(f"{'=' * 70}\n", file=sys.stderr)
    
    async def run_stdio(self):
        """
        Run the server in stdio mode.
        
        This is the main operation mode - server reads JSON from stdin
        and writes JSON responses to stdout.
        """
        if not await self.startup():
            return 1
        
        self._setup_signal_handlers()
        
        try:
            # Run server until shutdown signal
            server_task = asyncio.create_task(self.server.run_stdio())
            
            # Wait for either server completion or shutdown signal
            await asyncio.wait(
                [server_task, asyncio.create_task(self._shutdown_event.wait())],
                return_when=asyncio.FIRST_COMPLETED
            )
            
            # If shutdown signal received, stop the server
            if self._shutdown_event.is_set():
                self.server.running = False
                # Give server a moment to finish current request
                await asyncio.sleep(0.1)
            
            return 0
            
        except KeyboardInterrupt:
            print("\n\nKeyboard interrupt received.", file=sys.stderr)
            return 0
        except Exception as e:
            print(f"\n\nERROR during server execution: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc(file=sys.stderr)
            return 1
        finally:
            await self.shutdown()
    
    def run(self, args):
        """
        Main entry point - parse arguments and run the application.
        
        Args:
            args: Parsed command-line arguments
            
        Returns:
            Exit code (0 for success, non-zero for error)
        """
        if args.version:
            print(f"{APP_NAME} v{APP_VERSION}")
            return 0
        
        # Currently only stdio mode is supported
        if args.mode == "stdio":
            return asyncio.run(self.run_stdio())
        else:
            print(f"Error: Unsupported mode '{args.mode}'", file=sys.stderr)
            print("Currently supported modes: stdio", file=sys.stderr)
            return 1


def create_argument_parser() -> argparse.ArgumentParser:
    """
    Create and configure the argument parser.
    
    Returns:
        Configured ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        prog="mcp-server",
        description=f"{APP_NAME} - {APP_DESCRIPTION}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start the server (default stdio mode)
  python app.py

  # Start with explicit mode
  python app.py --mode stdio

  # Show version
  python app.py --version

Configuration:
  The server reads configuration from .env file or environment variables.
  See .env.example for available options.

Logging:
  Logs are written to the logs/ directory:
    - logs/mcp_server.log    (general logs)
    - logs/mcp_errors.log    (errors only)
    - logs/mcp_tools.log     (tool executions)

For more information, see PACKAGE_ARCHITECTURE.txt
        """
    )
    
    parser.add_argument(
        "--mode",
        choices=["stdio"],
        default="stdio",
        help="Server operation mode (default: stdio)"
    )
    
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit"
    )
    
    return parser


def main():
    """
    Main entry point for the application.
    
    Parses arguments and runs the application.
    """
    parser = create_argument_parser()
    args = parser.parse_args()
    
    app = Application()
    exit_code = app.run(args)
    
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
